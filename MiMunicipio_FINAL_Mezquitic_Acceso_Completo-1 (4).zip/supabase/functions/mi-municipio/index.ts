// Authenticated API; service key exists only in Supabase's server environment.
const URL=Deno.env.get('SUPABASE_URL')!;
const SERVICE=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const ANON=Deno.env.get('SUPABASE_ANON_KEY')!;
const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Cache-Control':'no-store','Content-Type':'application/json'};
const fail=(message:string)=>{throw new Error(message)};
async function api(path:string,method='GET',body?:any,token=SERVICE){
 const res=await fetch(URL+path,{method,headers:{apikey:SERVICE,Authorization:'Bearer '+token,'Content-Type':'application/json',Prefer:'return=representation'},body:body===undefined?undefined:JSON.stringify(body)});
 const text=await res.text(); let data:any;try{data=text?JSON.parse(text):null}catch{fail('Servicio temporalmente no disponible')}
 if(!res.ok)throw new Error(data?.msg||data?.message||data?.error_description||'No se pudo completar la operación');return data;
}
const rpc=(name:string,args:any)=>api('/rest/v1/rpc/'+name,'POST',args);
const rows=(table:string,query:string)=>api('/rest/v1/'+table+'?'+query);
const clean=(v:any)=>String(v??'').trim();
const eq=(v:any)=>encodeURIComponent(String(v));
async function profile(id:string){const rs=await rows('mm_profiles','id=eq.'+eq(id)+'&select=*');return rs[0]}
const delegation=(p:any)=>/^(delegación de mezquitic|mezquitic)/i.test(p?.department||'')&&p?.role!=='Administrador';
function validateProfile(p:any){
 if(!p.name||p.name.length>100||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(p.email)||p.email.length>254||!/^[a-z0-9_.-]{3,40}$/.test(p.username))fail('Revisa nombre, correo y usuario (3 a 40 letras, números, punto, guion o guion bajo)');
}
async function putProfile(p:any){
 const data={...p};delete data.password;delete data.id; delete data._version;
 return api('/rest/v1/mm_profiles','POST',{id:p.id,username:p.username,email:p.email,data,active:p.active!==false});
}
async function audit(actor:string,action:string,target:string){await api('/rest/v1/mm_audit','POST',{actor,action,target})}
async function hash(text:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))).map(x=>x.toString(16).padStart(2,'0')).join('')}
Deno.serve(async req=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
 if(req.method!=='POST')return new Response(JSON.stringify({error:'Usa POST'}),{status:405,headers:cors});
 try{
  if(Number(req.headers.get('content-length')||0)>3500000)fail('Archivo demasiado grande');
  const raw=await req.text();if(raw.length>3500000)fail('Archivo demasiado grande');
  const b=JSON.parse(raw),action=b.action,payload=b.payload||{};
  const reply=(data:any)=>new Response(JSON.stringify(data),{headers:cors});
  const token=req.headers.get('Authorization')?.replace(/^Bearer\s+/i,'');
  let who:any=null,p:any=null;
  if(token&&token!==ANON){
   try{const user=await api('/auth/v1/user','GET',undefined,token);who=user.id;p=await profile(who)}catch{fail('La sesión venció. Vuelve a iniciar sesión')}
   if(!p||!p.active)fail('Cuenta desactivada o eliminada');
  }
  const ip=req.headers.get('x-forwarded-for')?.split(',')[0]||req.headers.get('cf-connecting-ip')||'unknown';
  const limit=async(scope:string,max:number)=>{if(!await rpc('mm_rate',{k:scope+':'+await hash(ip),max_hits:max}))fail('Demasiados intentos. Espera 15 minutos antes de volver a intentar')};
  if(action==='login'){
   await limit('login',40);
   const identity=clean(payload.identity).toLowerCase();
   if(!identity||identity.length>254)fail('Usuario o contraseña incorrectos');
   const found=await rows('mm_profiles',(identity.includes('@')?'email':'username')+'=eq.'+eq(identity)+'&select=id,email,active,data');
   if(!found[0]||!found[0].active)fail('Usuario o contraseña incorrectos');
   let session:any;try{session=await api('/auth/v1/token?grant_type=password','POST',{email:found[0].email,password:payload.password},ANON)}catch{fail('Usuario o contraseña incorrectos')}
   if(payload.role&&found[0].data.role!==payload.role)fail('Selecciona el tipo de acceso correspondiente a tu cuenta');
   if(payload.citizen&&found[0].data.role!=='Ciudadano')fail('Usa el acceso de personal municipal');
   await audit(found[0].id,'Sesión iniciada',found[0].data.username);
   return reply({session,snapshot:await rpc('mm_snapshot',{who:found[0].id})});
  }
  if(action==='refresh'){
   const session=await api('/auth/v1/token?grant_type=refresh_token','POST',{refresh_token:payload.refresh_token},ANON);return reply({session});
  }
  if(action==='register'){
   await limit('register',10);
   const input={name:clean(payload.name),username:clean(payload.username).toLowerCase(),email:clean(payload.email).toLowerCase(),phone:clean(payload.phone).slice(0,30),role:'Ciudadano',department:'',active:true,mustChangeCredentials:false,created:new Date().toLocaleDateString('es-MX',{timeZone:'America/Mexico_City'})};
   validateProfile(input);if(String(payload.password||'').length<8)fail('La contraseña debe tener al menos 8 caracteres');
   if((await rows('mm_profiles','username=eq.'+eq(input.username)+'&select=id')).length)fail('Ese usuario ya está registrado');
   const u=await api('/auth/v1/admin/users','POST',{email:input.email,password:payload.password,email_confirm:true});
   try{await putProfile({...input,id:u.id})}catch(e){await api('/auth/v1/admin/users/'+u.id,'DELETE');throw e}
   const session=await api('/auth/v1/token?grant_type=password','POST',{email:input.email,password:payload.password},ANON);
   await audit(u.id,'Registro ciudadano',input.username);return reply({session,snapshot:await rpc('mm_snapshot',{who:u.id})});
  }
  if(action==='recover'){
   await limit('recover',8);
   const email=clean(payload.email).toLowerCase();
   // Recovery always returns the same response; ownership is proved through email.
   try{await api('/auth/v1/recover?redirect_to='+encodeURIComponent('https://mimunicipioapp.netlify.app/'),'POST',{email},ANON)}catch{}
   return reply({ok:true});
  }
  if(action==='lookup'){
   await limit('lookup',120); const folio=clean(payload.folio).toUpperCase();
   if(!/^[A-Z0-9]{1,10}-\d{4}-\d{6}$/.test(folio))return reply({reports:[]});
   const snap=await rpc('mm_snapshot',{who:null,folio});return reply({reports:snap.reports});
  }
  if(action==='snapshot')return reply(await rpc('mm_snapshot',{who}));
  if(!who||!p)fail('Inicia sesión para continuar');
  if(action==='logout'){await api('/auth/v1/logout?scope=local','POST',undefined,token);return reply({ok:true})}
  if(action==='password'){
   if(String(payload.password||'').length<8)fail('Usa al menos 8 caracteres');
   await api('/auth/v1/user','PUT',{password:payload.password},token);return reply({ok:true});
  }
  if(action==='force-profile'){
   const next={...p.data,name:clean(payload.name),username:clean(payload.username).toLowerCase(),email:clean(payload.email).toLowerCase(),mustChangeCredentials:false,profileUpdatedAt:new Date().toISOString()};validateProfile(next);
   if(String(payload.password||'').length<12)fail('Usa al menos 12 caracteres');
   const duplicate=await rows('mm_profiles','username=eq.'+eq(next.username)+'&id=neq.'+who+'&select=id');if(duplicate.length)fail('Ese usuario ya está registrado');
   await api('/auth/v1/admin/users/'+who,'PUT',{email:next.email,password:payload.password,email_confirm:true});
   await api('/rest/v1/mm_profiles?id=eq.'+who,'PATCH',{username:next.username,email:next.email,data:next});
   await audit(who,'Datos de acceso actualizados',next.username);return reply(await rpc('mm_snapshot',{who}));
  }
  if(p.data.mustChangeCredentials)fail('Actualiza tus datos antes de continuar');
  if(action==='save-user'||action==='toggle-user'||action==='delete-account'){
   const target=payload.id?await profile(payload.id):null;
   if(action==='delete-account'){
    if(!target||target.data.role!=='Ciudadano'||(target.id!==who&&!['Administrador','Administrador de Mezquitic'].includes(p.data.role)))fail('No puedes eliminar esta cuenta');
    await audit(who,'Cuenta ciudadana eliminada',target.username);
    await api('/auth/v1/admin/users/'+target.id,'DELETE');return reply({ok:true});
   }
   if(!['Administrador','Administrador de Mezquitic'].includes(p.data.role))fail('Sin permiso para administrar usuarios');
   if(action==='toggle-user'){
    if(!target||target.id===who||target.data.systemKey)fail('No se puede desactivar esa cuenta');
    
    await api('/rest/v1/mm_profiles?id=eq.'+target.id,'PATCH',{active:!target.active,data:{...target.data,active:!target.active}});
   }else{
    const input={...target?.data,name:clean(payload.name),username:clean(payload.username).toLowerCase(),email:clean(payload.email).toLowerCase(),role:clean(payload.role),department:clean(payload.department),active:payload.active!==false};validateProfile(input);
    if(!['Administrador','Administrador de Mezquitic','Dependencia'].includes(input.role))fail('Rol inválido');
    if(target?.data.systemKey&&(input.role!==target.data.role||input.department!==target.data.department||!input.active))fail('Conserva el rol y acceso de la administración principal');
    if(target?.id===who&&!input.active)fail('No puedes desactivar tu propia cuenta');
    
    const config=(await rows('mm_config','id=eq.main&select=data'))[0].data;
    if(input.role==='Administrador')input.department='Administración central';else if(!config.departments.some((d:any)=>d.name===input.department))fail('Dependencia inválida');
    const duplicate=await rows('mm_profiles','username=eq.'+eq(input.username)+'&select=id');if(duplicate.some((x:any)=>x.id!==target?.id))fail('Ese usuario ya está registrado');
    if(payload.password&&String(payload.password).length<8)fail('Usa al menos 8 caracteres');
    if(target){
     await api('/auth/v1/admin/users/'+target.id,'PUT',{email:input.email,...(payload.password?{password:payload.password}:{}) ,email_confirm:true});
     await api('/rest/v1/mm_profiles?id=eq.'+target.id,'PATCH',{username:input.username,email:input.email,active:input.active,data:input});
    }else{
     if(!payload.password)fail('Asigna una contraseña');
     const u=await api('/auth/v1/admin/users','POST',{email:input.email,password:payload.password,email_confirm:true});
     try{await putProfile({...input,id:u.id,mustChangeCredentials:false})}catch(e){await api('/auth/v1/admin/users/'+u.id,'DELETE');throw e}
    }
   }
   await audit(who,action,payload.username||target?.username);return reply(await rpc('mm_snapshot',{who}));
  }
  const result=await rpc('mm_command',{who,action,payload,request_id:b.requestId||crypto.randomUUID()});
  return reply({result,snapshot:await rpc('mm_snapshot',{who})});
 }catch(e){return new Response(JSON.stringify({error:e.message||'No se pudo completar la operación'}),{status:400,headers:cors})}
});
