-- Mi Municipio: all data access goes through the authenticated Edge Function.
-- No anonymous/authenticated direct table or RPC access.
create table public.mm_profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique check(username=lower(username) and length(username) between 3 and 40),
 email text not null unique,
 data jsonb not null,
 active boolean not null default true
);
create table public.mm_reports (
 id text primary key, owner_id uuid references public.mm_profiles(id) on delete set null,
 version integer not null default 1, data jsonb not null
);
create table public.mm_config (id text primary key, data jsonb not null, version integer not null default 1);
create table public.mm_audit (id bigint generated always as identity primary key, actor uuid, at timestamptz not null default now(), action text not null, target text);
create table public.mm_supports (report_id text references public.mm_reports(id) on delete cascade, actor uuid references public.mm_profiles(id) on delete cascade, primary key(report_id,actor));
create table public.mm_backups (report_id text references public.mm_reports(id) on delete cascade, actor uuid references public.mm_profiles(id) on delete cascade, version integer not null, primary key(report_id,actor));
create table public.mm_requests (actor uuid not null, request_id uuid not null, result jsonb not null, created_at timestamptz not null default now(), primary key(actor,request_id));
create table public.mm_limits (key text primary key, window_at timestamptz not null default now(), hits integer not null default 1);
create sequence public.mm_folio_seq;
create index on public.mm_reports(owner_id);
create index on public.mm_supports(actor);
create index on public.mm_audit(at desc);
alter table public.mm_profiles enable row level security;
revoke all on public.mm_profiles from anon, authenticated;
grant all on public.mm_profiles to service_role;
alter table public.mm_reports enable row level security;
revoke all on public.mm_reports from anon, authenticated;
grant all on public.mm_reports to service_role;
alter table public.mm_config enable row level security;
revoke all on public.mm_config from anon, authenticated;
grant all on public.mm_config to service_role;
alter table public.mm_audit enable row level security;
revoke all on public.mm_audit from anon, authenticated;
grant all on public.mm_audit to service_role;
alter table public.mm_supports enable row level security;
revoke all on public.mm_supports from anon, authenticated;
grant all on public.mm_supports to service_role;
alter table public.mm_backups enable row level security;
revoke all on public.mm_backups from anon, authenticated;
grant all on public.mm_backups to service_role;
alter table public.mm_requests enable row level security;
revoke all on public.mm_requests from anon, authenticated;
grant all on public.mm_requests to service_role;
alter table public.mm_limits enable row level security;
revoke all on public.mm_limits from anon, authenticated;
grant all on public.mm_limits to service_role;
grant usage, select on sequence public.mm_folio_seq,public.mm_audit_id_seq to service_role;
create function public.mm_allowed(p jsonb,r jsonb) returns boolean language sql immutable set search_path='' as $$
 select p->>'role'='Administrador' or (p->>'role'='Administrador de Mezquitic' and r->>'location' ~* 'mezquitic') or (p->>'role'='Dependencia' and (r->>'department'=p->>'department' or coalesce(r->'departments','[]') ? (p->>'department')))
$$;
create function public.mm_rate(k text, max_hits integer) returns boolean language plpgsql set search_path='' as $$
declare n integer;
begin
 insert into public.mm_limits(key) values(k) on conflict(key) do update set
 hits=case when mm_limits.window_at < now()-interval '15 minutes' then 1 else mm_limits.hits+1 end,
 window_at=case when mm_limits.window_at < now()-interval '15 minutes' then now() else mm_limits.window_at end returning hits into n;
 return n<=max_hits;
end $$;
create function public.mm_snapshot(who uuid default null, folio text default null) returns jsonb language plpgsql set search_path='' as $$
declare p jsonb; reports jsonb; users jsonb; citizens jsonb; conf jsonb; audits jsonb; backs jsonb;
begin
 select data || jsonb_build_object('id',id,'active',active) into p from public.mm_profiles where id=who and active;
 if who is not null and p is null then raise exception 'Cuenta desactivada o eliminada'; end if;
 select data || jsonb_build_object('_version',version) into conf from public.mm_config where id='main';
 if p->>'mustChangeCredentials'='true' then return jsonb_build_object('profile',p,'reports','[]'::jsonb,'users','[]'::jsonb,'citizens','[]'::jsonb,'config',conf,'audit','[]'::jsonb,'backups','[]'::jsonb); end if;
 select coalesce(jsonb_agg(case when public.mm_allowed(p,r.data) then r.data || jsonb_build_object('id',r.id,'_version',r.version,'_owner',r.owner_id) when p->>'role'='Ciudadano' and (r.owner_id=who or exists(select 1 from public.mm_supports s where s.report_id=r.id and s.actor=who)) then (r.data - 'notes' - 'citizen' - 'contact') || jsonb_build_object('_mine',true,'notes',coalesce((select jsonb_agg(n) from jsonb_array_elements(coalesce(r.data->'notes','[]')) n where n->>'internal'='false'),'[]'::jsonb)) else
 jsonb_build_object('id',r.id,'category',r.data->'category','title',r.data->'title','status',r.data->'status','department',r.data->'department','location',r.data->'location','created',r.data->'created','updated',r.data->'updated','reportCount',r.data->'reportCount','notes',coalesce((select jsonb_agg(n) from jsonb_array_elements(coalesce(r.data->'notes','[]')) n where n->>'internal'='false'),'[]'::jsonb),'_mine',r.owner_id=who or exists(select 1 from public.mm_supports s where s.report_id=r.id and s.actor=who)) end order by r.id desc),'[]') into reports
 from public.mm_reports r where
 (folio is not null and r.id=folio and (p is null or p->>'role'='Ciudadano' or public.mm_allowed(p,r.data))) or
 (folio is null and p is not null and (public.mm_allowed(p,r.data) or (p->>'role'='Ciudadano' and (r.owner_id=who or exists(select 1 from public.mm_supports s where s.report_id=r.id and s.actor=who)))));
 select coalesce(jsonb_agg(data || jsonb_build_object('id',id,'active',active) order by username),'[]') into users from public.mm_profiles where data->>'role'<>'Ciudadano' and (p->>'role'='Administrador' or id=who or (p->>'role'='Administrador de Mezquitic' and data->>'role'<>'Administrador' and (data->>'department' ~* '^(delegación de mezquitic|mezquitic)')));
 select coalesce(jsonb_agg(data || jsonb_build_object('id',id,'active',active) order by username),'[]') into citizens from public.mm_profiles where data->>'role'='Ciudadano' and (p->>'role'='Administrador' or id=who);
 select coalesce(jsonb_agg(x),'[]') into audits from (select jsonb_build_object('date',to_char(a.at at time zone 'America/Mexico_City','DD/MM/YYYY'),'timestamp',a.at,'user',coalesce(u.data->>'name','Sistema'),'role',u.data->>'role','action',a.action,'target',a.target) x from public.mm_audit a left join public.mm_profiles u on a.actor=u.id where p->>'role'='Administrador' order by a.id desc limit 2000) t;
 select coalesce(jsonb_agg(b.report_id),'[]') into backs from public.mm_backups b join public.mm_reports r on r.id=b.report_id and r.version=b.version where b.actor=who;
 return jsonb_build_object('profile',p,'reports',reports,'users',users,'citizens',citizens,'config',conf,'audit',audits,'backups',backs);
end $$;
create function public.mm_command(who uuid, action text, payload jsonb, request_id uuid) returns jsonb language plpgsql set search_path='' as $$
declare p jsonb; r public.mm_reports; d jsonb; result jsonb; conf jsonb; lat double precision; lng double precision; cnt integer; dep text; new_id text; stamp text=to_char(now() at time zone 'America/Mexico_City','DD/MM/YYYY');
begin
 -- Serialize writes, including retries and duplicate detection, inside one transaction.
 perform pg_advisory_xact_lock(73201901);
 select q.result into result from public.mm_requests q where q.actor=who and q.request_id=mm_command.request_id;
 if found then return result; end if;
 select data || jsonb_build_object('id',id) into p from public.mm_profiles where id=who and active;
 if p is null or p->>'mustChangeCredentials'='true' then raise exception 'Inicia sesión y actualiza tus datos de acceso'; end if;
 select data into conf from public.mm_config where id='main';
 if action='create-report' then
  if p->>'role'<>'Ciudadano' then raise exception 'Solo ciudadanía puede registrar reportes'; end if;
  if coalesce(length(payload->>'description'),0) not between 1 and 1000 or coalesce(length(payload->>'location'),0) not between 1 and 500 or not coalesce(conf->'rules' ? (payload->>'category'),false) then raise exception 'Completa categoría, descripción y ubicación'; end if;
  lat=(payload->>'latitude')::double precision; lng=(payload->>'longitude')::double precision;
  if (lat is null)<>(lng is null) or lat not between -90 and 90 or lng not between -180 and 180 then raise exception 'Coordenadas inválidas'; end if;
  if lat is not null and lng is not null then
   select * into r from public.mm_reports t where t.data->>'category'=payload->>'category' and t.data->>'latitude' is not null and t.data->>'longitude' is not null and
    6371000*2*asin(sqrt(least(1.0,power(sin(radians((t.data->>'latitude')::double precision-lat)/2),2)+cos(radians(lat))*cos(radians((t.data->>'latitude')::double precision))*power(sin(radians((t.data->>'longitude')::double precision-lng)/2),2))))<=5 limit 1;
   if found then return jsonb_build_object('duplicate',true,'id',r.id,'reportCount',r.data->'reportCount'); end if;
   -- Same point must always use existing case; allowSeparate is never honored.
   if found then raise exception 'Agrega tu apoyo al folio existente'; end if;
  end if;
  dep=conf->'rules'->>(payload->>'category');
  new_id=coalesce(conf->'settings'->>'folioPrefix','MUN')||'-'||extract(year from now())||'-'||lpad(nextval('public.mm_folio_seq')::text,6,'0');
  d=jsonb_build_object('id',new_id,'category',payload->'category','title',payload->'category','description',payload->'description','location',payload->'location','latitude',lat,'longitude',lng,'coords',case when lat is null then '' else lat::text||', '||lng::text end,'department',dep,'departments','[]'::jsonb,'status',case when dep='Mesa de Control Municipal' then 'Recibido' else 'Asignado' end,'reportCount',1,'created',stamp,'updated',stamp,'citizen',p->'name','contact',coalesce(payload->'contact',p->'email'),'image',coalesce(payload->'image','""'),'notes',jsonb_build_array(jsonb_build_object('text','El reporte fue recibido y turnado por el sistema.','user','Sistema Mi Municipio','date',stamp,'internal',true)));
  if length(coalesce(d->>'image',''))>2500000 then raise exception 'La fotografía es demasiado grande'; end if;
  insert into public.mm_reports(id,owner_id,data) values(new_id,who,d);
  result=jsonb_build_object('id',new_id);
 elsif action='support' then
  if p->>'role'<>'Ciudadano' then raise exception 'Solo ciudadanía puede agregar apoyo'; end if;
  select * into r from public.mm_reports where id=payload->>'id' for update;
  if not found then raise exception 'No se encontró el reporte'; end if;
  cnt=(payload->>'count')::integer;
  if cnt is null or cnt not between 1 and 100 then raise exception 'Cantidad inválida'; end if;
  d=r.data||jsonb_build_object('reportCount',coalesce((r.data->>'reportCount')::integer,1)+cnt,'updated',stamp,'notes',coalesce(r.data->'notes','[]')||jsonb_build_array(jsonb_build_object('text',cnt||' reporte(s) adicional(es) de la misma situación.','user',p->'name','date',stamp,'internal',true)));
  update public.mm_reports set data=d,version=version+1 where id=r.id;
  insert into public.mm_supports values(r.id,who) on conflict do nothing;
  result=jsonb_build_object('id',r.id,'reportCount',d->'reportCount');
 elsif action in ('update-report','evidence','backup','delete-report') then
  select * into r from public.mm_reports where id=payload->>'id' for update;
  if not found or not coalesce(public.mm_allowed(p,r.data),false) then raise exception 'Sin permiso para este reporte'; end if;
  if r.version<>coalesce((payload->>'version')::integer,-1) then raise exception 'Otro dispositivo actualizó este reporte. Recarga y vuelve a intentar'; end if;
  if action='backup' then
   if p->>'role'<>'Administrador' then raise exception 'Solo administración municipal'; end if;
   insert into public.mm_backups values(r.id,who,r.version) on conflict(report_id,actor) do update set version=excluded.version;
  elsif action='delete-report' then
   if p->>'role'<>'Administrador' or not exists(select 1 from public.mm_backups b where b.actor=who and b.report_id=r.id and b.version=r.version) then raise exception 'Primero descarga y confirma una copia actualizada'; end if;
   delete from public.mm_reports where id=r.id;
  else
   d=r.data;
   if action='update-report' then
    if coalesce(payload->>'status','') not in ('Recibido','Asignado','En proceso','En espera','Resuelto','Cerrado','Improcedente') then raise exception 'Estado inválido'; end if;
    d=d||jsonb_build_object('status',payload->'status','departments',coalesce(payload->'departments','[]'));
    if payload->>'department' is distinct from r.data->>'department' then
     if p->>'role' not in ('Administrador','Administrador de Mezquitic') then raise exception 'No puedes reasignar este reporte'; end if;
     d=d||jsonb_build_object('department',payload->'department');
    end if;
    if exists(select 1 from jsonb_array_elements_text(coalesce(d->'departments','[]')||jsonb_build_array(d->'department')) depname where not exists(select 1 from jsonb_array_elements(conf->'departments') x where x->>'name'=depname)) then raise exception 'Dependencia inválida'; end if;
    if length(coalesce(payload->>'publicNote',''))>2000 or length(coalesce(payload->>'internalNote',''))>2000 then raise exception 'Nota demasiado larga'; end if;
    if coalesce(payload->>'publicNote','')<>'' then d=jsonb_set(d,'{notes}',coalesce(d->'notes','[]')||jsonb_build_array(jsonb_build_object('text',payload->'publicNote','user',p->'name','date',stamp,'internal',false))); end if;
    if coalesce(payload->>'internalNote','')<>'' then d=jsonb_set(d,'{notes}',coalesce(d->'notes','[]')||jsonb_build_array(jsonb_build_object('text',payload->'internalNote','user',p->'name','date',stamp,'internal',true))); end if;
   else
    if coalesce(length(payload->>'image'),0)=0 or length(payload->>'image')>2500000 or payload->>'image' !~ '^data:image/(jpeg|png|webp);base64,' then raise exception 'Imagen inválida'; end if;
    d=d||jsonb_build_object('image',payload->'image');
    if length(coalesce(payload->>'note',''))>2000 then raise exception 'Nota demasiado larga'; end if;
    if coalesce(payload->>'note','')<>'' then d=jsonb_set(d,'{notes}',coalesce(d->'notes','[]')||jsonb_build_array(jsonb_build_object('text',payload->'note','user',p->'name','date',stamp,'internal',true))); end if;
   end if;
   update public.mm_reports set data=d||jsonb_build_object('updated',stamp),version=version+1 where id=r.id;
  end if;
  result=jsonb_build_object('id',r.id);
 elsif action in ('settings','rules','department') then
  if action<>'department' and p->>'role'<>'Administrador' then raise exception 'Solo administración municipal'; end if;
  if action='department' and p->>'role' not in ('Administrador','Administrador de Mezquitic') then raise exception 'Sin permiso'; end if;
  if (select version from public.mm_config where id='main')<>coalesce((payload->>'version')::integer,-1) then raise exception 'La configuración cambió en otro dispositivo. Recarga y vuelve a intentar'; end if;
  if action='department' then
   if p->>'role'='Administrador de Mezquitic' and payload->>'name' !~* '^mezquitic\b' then raise exception 'Usa el prefijo Mezquitic'; end if;
   if length(payload->>'name') not between 3 and 100 or exists(select 1 from jsonb_array_elements(conf->'departments') x where lower(x->>'name')=lower(payload->>'name')) then raise exception 'Nombre de dependencia inválido o repetido'; end if;
   conf=jsonb_set(conf,'{departments}',conf->'departments'||jsonb_build_array(jsonb_build_object('name',payload->>'name','icon','building','desc',left(payload->>'description',500))));
  elsif action='settings' then
   if coalesce(payload->'settings'->>'folioPrefix','') !~ '^[A-Z0-9]{1,10}$' then raise exception 'Prefijo inválido'; end if;
   conf=jsonb_set(conf,'{settings}',payload->'settings');
  else
   if exists(select 1 from jsonb_each_text(payload->'rules') kv where not (conf->'rules' ? kv.key) or not exists(select 1 from jsonb_array_elements(conf->'departments') x where x->>'name'=kv.value)) then raise exception 'Regla inválida'; end if;
   conf=jsonb_set(conf,'{rules}',conf->'rules'||payload->'rules');
  end if;
  update public.mm_config set data=conf,version=version+1 where id='main'; result='{}';
 else raise exception 'Acción desconocida'; end if;
 insert into public.mm_audit(actor,action,target) values(who,action,coalesce(result->>'id',action));
 insert into public.mm_requests values(who,request_id,result,now());
 return result;
end $$;
revoke all on function public.mm_allowed(jsonb,jsonb), public.mm_rate(text,integer), public.mm_snapshot(uuid,text), public.mm_command(uuid,text,jsonb,uuid) from public,anon,authenticated;
grant execute on function public.mm_allowed(jsonb,jsonb), public.mm_rate(text,integer), public.mm_snapshot(uuid,text), public.mm_command(uuid,text,jsonb,uuid) to service_role;

create policy mm_no_direct_client_access on public.mm_profiles to anon,authenticated using (false) with check (false);
create policy mm_no_direct_client_access on public.mm_reports to anon,authenticated using (false) with check (false);
create policy mm_no_direct_client_access on public.mm_config to anon,authenticated using (false) with check (false);
create policy mm_no_direct_client_access on public.mm_audit to anon,authenticated using (false) with check (false);
create policy mm_no_direct_client_access on public.mm_supports to anon,authenticated using (false) with check (false);
create policy mm_no_direct_client_access on public.mm_backups to anon,authenticated using (false) with check (false);
create policy mm_no_direct_client_access on public.mm_requests to anon,authenticated using (false) with check (false);
create policy mm_no_direct_client_access on public.mm_limits to anon,authenticated using (false) with check (false);
